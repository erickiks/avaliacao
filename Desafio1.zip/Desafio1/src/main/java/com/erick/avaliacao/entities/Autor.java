package com.erick.avaliacao.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="db_autor")
public class Autor {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	private String nome;
	
	private String pais;

	
	public Autor() {
		
	}

	public Autor(Long idAutor, String nome, String Pais) {
		super();
		this.id = idAutor;
		this.nome = nome;
		this.pais = Pais;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long idAutor) {
		this.id = idAutor;
	}

	public String getnome() {
		return nome;
	}

	public void setnome(String nome) {
		this.nome = nome;
	}
	
	public String getpais() {
		return pais;
	}

	public void setpais(String Pais) {
		this.pais = Pais;
	}
}
