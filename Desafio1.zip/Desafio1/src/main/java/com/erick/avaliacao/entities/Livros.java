package com.erick.avaliacao.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="db_livro")
public class Livros {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
	
	private Long ano;
	
	private String titulo;

	
	public Livros() {
		
	}

	public Livros(Long idLivros, Long ano, String Titulo) {
		super();
		this.id = idLivros;
		this.ano = ano;
		this.titulo = Titulo;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long idLivros) {
		this.id = idLivros;
	}

	public Long getano() {
		return ano;
	}

	public void setano(Long ano) {
		this.ano = ano;
	}
	
	public String gettitulo() {
		return titulo;
	}

	public void settitulo(String Titulo) {
		this.titulo = Titulo;
	}
}
