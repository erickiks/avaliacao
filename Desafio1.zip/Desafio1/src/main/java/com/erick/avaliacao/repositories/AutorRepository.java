package com.erick.avaliacao.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.erick.avaliacao.entities.Autor;


public interface AutorRepository extends JpaRepository<Autor, Long> {

}
