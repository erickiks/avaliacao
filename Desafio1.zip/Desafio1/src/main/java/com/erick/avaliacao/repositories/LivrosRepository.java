package com.erick.avaliacao.repositories;
import org.springframework.data.jpa.repository.JpaRepository;

import com.erick.avaliacao.entities.Livros;


public interface LivrosRepository extends JpaRepository<Livros, Long> {

}
