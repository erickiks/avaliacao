package com.erick.avaliacao.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erick.avaliacao.entities.Autor;
import com.erick.avaliacao.repositories.AutorRepository;


@Service
public class AutorService {
	private final AutorRepository autorRepository;
	
	@Autowired
	public AutorService(AutorRepository autorRepository) {
		this.autorRepository = autorRepository;
	}
	
	public Autor getAutorById(Long id) {
		return autorRepository.findById(id).orElse(null);
	}

	public List<Autor> getAllAutor() {
		return autorRepository.findAll();
	}
	
	public Autor saveAutor(Autor autor) {
		return autorRepository.save(autor);
	}

	public void deleteAutor(Long id) {
		autorRepository.deleteById(id);
	}
	
	public 	Autor updateAutor(Long id, Autor novoautor) {
		Optional<Autor> autorOptional = autorRepository.findById(id);
        if (autorOptional.isPresent()) {
        	Autor autorExistente = autorOptional.get();
           	autorExistente.setnome(novoautor.getnome());
        	autorExistente.setpais(novoautor.getpais());
            return autorRepository.save(autorExistente); 
        } else {
            return null; 
        }
    }
}
