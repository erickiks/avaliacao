package com.erick.avaliacao.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erick.avaliacao.entities.Categoria;
import com.erick.avaliacao.repositories.CategoriaRepository;


@Service
public class CategoriaService {
	private final CategoriaRepository categoriaRepository;
	
	@Autowired
	public CategoriaService(CategoriaRepository categoriaRepository) {
		this.categoriaRepository = categoriaRepository;
	}
	
	public Categoria getCategoriaById(Long id) {
		return categoriaRepository.findById(id).orElse(null);
	}

	public List<Categoria> getAllCategoria() {
		return categoriaRepository.findAll();
	}
	
	public Categoria saveCategoria(Categoria categoria) {
		return categoriaRepository.save(categoria);
	}

	public void deleteCategoria(Long id) {
		categoriaRepository.deleteById(id);
	}
	
	public 	Categoria updateAutor(Long id, Categoria novocategoria) {
		Optional<Categoria> categoriaOptional = categoriaRepository.findById(id);
        if (categoriaOptional.isPresent()) {
        	Categoria categoriaExistente = categoriaOptional.get();
           	categoriaExistente.setnome(novocategoria.getnome());
        	categoriaExistente.setdescricao(novocategoria.getdescricao());
            return categoriaRepository.save(categoriaExistente); 
        } else {
            return null; 
        }
    }
}

