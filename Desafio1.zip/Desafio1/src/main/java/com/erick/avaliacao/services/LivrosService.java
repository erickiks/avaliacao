package com.erick.avaliacao.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.erick.avaliacao.entities.Livros;
import com.erick.avaliacao.repositories.LivrosRepository;


@Service
public class LivrosService {
	private final LivrosRepository livrosRepository;
	
	@Autowired
	public LivrosService(LivrosRepository livrosRepository) {
		this.livrosRepository = livrosRepository;
	}
	
	public Livros getLivrosById(Long id) {
		return livrosRepository.findById(id).orElse(null);
	}

	public List<Livros> getAllLivros() {
		return livrosRepository.findAll();
	}
	
	public Livros saveLivros(Livros livros) {
		return livrosRepository.save(livros);
	}

	public void deleteLivros(Long id) {
		livrosRepository.deleteById(id);
	}
	
	public Livros updateLivros(Long id, Livros novolivros) {
		Optional<Livros> livrosOptional = livrosRepository.findById(id);
        if (livrosOptional.isPresent()) {
        	Livros livrosExistente = livrosOptional.get();
           	livrosExistente.setano(novolivros.getano());
        	livrosExistente.settitulo(novolivros.gettitulo());
            return livrosRepository.save(livrosExistente); 
        } else {
            return null; 
        }
    }
}
